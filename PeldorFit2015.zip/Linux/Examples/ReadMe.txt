1. Open Command Prompt
2. Set the directory to where the PeldorFit executable is saved:
    cd .../PeldorFit2015/Linux/
3. Set the permission properties
    chmod 755 peldorfit
3. Set the path to the config file and run the program:
    sh PeldorFit.sh "Examples/bisnitroxide_config.cfg"
4. The program outputs the current progress to the Command Prompt
   and saves the fitting results into the "Examples/Results/" folder.
