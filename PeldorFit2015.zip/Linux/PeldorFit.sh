#!/bin/bash

# Set the path to the libraries
PROGRAM_DIRECTORY="`dirname "$0"`"
export LD_LIBRARY_PATH="$PROGRAM_DIRECTORY/lib"

# Run the program with the specified path to the config file as an argument
"$PROGRAM_DIRECTORY/peldorfit" "$@"
# echo ./peldorfitv2 "$@"
