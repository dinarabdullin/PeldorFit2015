1. Open Command Prompt
2. Set the directory to where the PeldorFit executable is saved:
    cd .../PeldorFitV2/Windows
3. Set the path to the config file and run the program:
    PeldorFit.exe "Examples/bisnitroxide_config.cfg"
4. The program will output the progress to the Command Prompt
   and will save the fitting results into the "Examples/Results/" folder.